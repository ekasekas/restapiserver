<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu_model extends CI_Model {

    public function getAll(){
        $this->db->select('*');
        $this->db->from('t_user');
        $this->db->join('t_role','t_role.id = t_user.role_id');
        $this->db->where('role_id = 1');
        return $this->db->get()->result();
    }

}
?>
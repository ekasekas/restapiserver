<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {

    public function index(){
        $data['user'] = $this->db->get_where('t_user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->model('Menu_model');
        $data['hasil'] = $this->Menu_model->getAll();
        $this->load->view('dashboard/mahasiswa', $data);
        
    }

    public function addMessage(){

        $data['user'] = $this->db->get_where('t_user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->model('Menu_model');
        $data['hasil'] = $this->Menu_model->getAll();

        $this->form_validation->set_rules('message', 'Message', 'required|trim');
        
        if($this->form_validation->run() == false){
            $this->load->view('dashboard/mahasiswa', $data);
        }else{
            $data = [
                'sender' => $this->input->post('sender'),
                'receiver' => $this->input->post('receiver'),
                'tgl_konsultasi' => $this->input->post('tgl_konsultasi'),
                'message' => $this->input->post('message'),
                'status' => 'Menunggu'
            ];
            $this->db->insert('t_konsultasi', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New  Sub Menu Added</div>');
            redirect('Mahasiswa');
        }
    }
}

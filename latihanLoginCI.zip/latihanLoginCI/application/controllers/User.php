<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

         public function __construct() {
   	     parent::__construct();
			$this->load->model('m_user');
			$this->load->helper('download');
         }

	public function index(){
        
        if($this->session->userdata('is_login')==TRUE)
          {
		  redirect('user/securepage','refresh');
          }

		$this->template->load('role','user/form_login');
		
	}

	public function register() {

		if($this->session->userdata('is_login')==TRUE)
          {
          redirect('user/securepage','refresh');
          }

		$this->template->load('role','user/form_register');
		
	}

	public function register_proses(){

	$this->form_validation->set_rules('nama', 'Nama', 'trim|required|min_length[3]|max_length[22]');
	$this->form_validation->set_rules('email', 'E-mail', 'trim|required|min_length[3]|max_length[45]|is_unique[user.email]');
	$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[5]|max_length[12]');

	if ($this->form_validation->run() == TRUE ) {

		   if($this->m_user->m_register()){
           
           $this->session->set_flashdata('pesan', 'Register berhasil, silahkan  Sign In.');
           redirect('/','refresh');

		   }else{

           $this->session->set_flashdata('pesan', 'Register user gagal!');
           redirect('/','refresh');

		   }

	} else {
		
		$this->template->load('role','user/form_register');
	}

	
		
	}

	public function login_proses() {

	$this->form_validation->set_rules('email', 'E-mail', 'trim|required|min_length[3]|max_length[45]');
	$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[5]|max_length[12]');

    if ($this->form_validation->run() == TRUE) {
    	
          if($this->m_user->m_cek_mail()->num_rows()==1) {
          
             $db=$this->m_user->m_cek_mail()->row();
             if(hash_verified($this->input->post('password'),$db->password)) {

                     $data_login=array('is_login'=>TRUE,
                             	'email'  	=>$db->email,
							 	'nama'   	=>$db->nama,
							 	'alamat' 	=>$db->alamat,
								'kota' 		=>$db->kota,
								'data_bank' =>$db->data_bank
					);
					 
					 $nama = $this->session->userdata('nama');
					 $this->session->set_userdata($data_login);
					 $this->load->helper('url');
                     redirect('user/securepage/' . $this->session->userdata('nama'));

                        } else {

                        $this->session->set_flashdata('pesan', 'Login gagal: password salah!');
                        redirect('/','refresh');

                        }

          } else { // jika email tidak terdaftar!
           
           $this->session->set_flashdata('pesan', 'Login gagal: email salah!');
           redirect('/','refresh');

          }

    } else { 

    	$this->template->load('role','user/form_login');
    }

	}


	public function securepage() {
		$nama = $this->session->userdata('nama');
		if($this->session->userdata('is_login')==FALSE)
          {
          redirect('/','refresh');
          }

        $this->template->load('role','user/securepage');

	}

	public function edit(){
        $data['user'] = $this->db->get_where('user', ['email' => 
        $this->session->userdata('email')])->row_array();

		$email= $this->session->userdata('email');
		
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        
        if($this->form_validation->run() == false){
            $this->template->load('role','user/edit', $data);
        }else{
            $nama = $this->input->post('nama');
            $email = $this->input->post('email');
            $alamat = $this->input->post('alamat');
            $kota = $this->input->post('kota');
            $data_bank = $this->input->post('data_bank');

            $this->db->set('nama', $nama);
            $this->db->set('alamat', $alamat);
            $this->db->set('kota', $kota);
            $this->db->set('data_bank', $data_bank);

            $this->db->where('email', $email);

            $this->db->update('user');
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your Profile Has Been Changed</div>');
            redirect('user/securepage/' . $this->session->userdata('nama'));

        }
	}
	
	public function lakukan_download(){				
		force_download('tema/SOAL POSTEST.pdf',NULL);
	}

	public function logout() {

		$this->session->unset_userdata('is_login');
		$this->session->unset_userdata('nama');
		$this->session->unset_userdata('email');

		session_destroy();
		//$this->session->set_flashdata('pesan', 'Sign Out Berhasil!');
		redirect('/','refresh');
	}

}

/* End of file User.php */
/* Location: ./application/controllers/User.php */
<div class="row">
    <div class="col-lg">
        
            <?= form_open_multipart('user/edit'); ?>
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" class="form-control" id="nama" name="nama" value="<?= $user['nama'];?>">
                    <?= form_error('nama', '<small class="text-danger pl=3">', '</small>');?>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" id="email" name="email" value="<?= $user['email'];?>" readonly>
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" class="form-control" id="alamat" name="alamat" value="<?= $user['alamat'];?>">
                </div>
                <div class="form-group">
                    <label>Kota</label>
                    <input type="text" class="form-control" id="kota" name="kota" value="<?= $user['kota'];?>">
                </div>
                <div class="form-group">
                    <label>Data Bank</label>
                    <input type="text" class="form-control" id="data_bank" name="data_bank" value="<?= $user['data_bank'];?>">
                </div>
                
                <button type="submit" class="btn btn-primary">Save Changes</button>
                        
            </form>

    </div>
</div>
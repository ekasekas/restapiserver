  <div class="col-md-8">

        <h2 class="my-4">Login
          <small>berhasil</small>
        </h2>

        <p>
        	Selamat datang: <b><?php echo $this->session->userdata('nama');  ?></b>,<br>

        	Ini adalah halaman user / member area yang telah di amankan oleh sistem login hash & session login.
        </p>

         Keluar halaman: <?php echo anchor('user/logout', 'Sign Out', 'attributes'); ?>

  </div>
  <div class="col-md-8">

        <h2 class="my-4">Login
          <small>berhasil</small>
        </h2>

        <p>
        	Selamat datang: <b><?php echo $this->session->userdata('nama');  ?></b>,<br>
          Alamat: <b><?php echo $this->session->userdata('alamat');  ?></b>,<br>
        	Kota: <b><?php echo $this->session->userdata('kota');  ?></b>,<br>
        	Data Bank: <b><?php echo $this->session->userdata('data_bank');  ?></b>,<br>
         
        	Ini adalah halaman user / member area yang telah di amankan oleh sistem login hash & session login.
        </p>

        <p>Selamat, anda sudah dapat mengunduh soal dengan gratis. <a href="<?php echo base_url().'user/lakukan_download' ?>">Download soal</a></p>
        
        

        <?= $this->session->flashdata('message');?>
        
        <br>
        edit profil anda? <a class="btn btn-warning" href="<?= base_url('user/edit/') ; ?>">Ya</a>

         Keluar halaman: <?php echo anchor('user/logout', 'Sign Out', 'attributes'); ?>

  </div>
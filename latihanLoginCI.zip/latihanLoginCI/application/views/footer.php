
</div></div>
<p>&nbsp;</p>
<!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; EkaOcta2020</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="<?php echo base_url('tema/blog-home/');?>vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url('tema/blog-home/');?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
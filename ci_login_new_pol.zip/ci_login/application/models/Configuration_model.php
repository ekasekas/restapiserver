<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Configuration_model extends CI_Model {

    function edit_device_m($where,$table){                              
        return $this->db->get_where($table,$where);
    }

    public function deletedevice_m($id){
        $this->db->delete('m_tagname', ['id' => $id]);
    }

    function edit_formula_m($where,$table){                              
        return $this->db->get_where($table,$where);
    }

    public function delete_formula_m($id){
        $this->db->delete('formula_perhitungan', ['id_perhitungan' => $id]);
    }
}
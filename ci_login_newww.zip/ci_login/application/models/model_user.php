<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class model_user extends CI_Model {

    public function getRole($id){
        $id = $this->session->userdata('id');
        $this->db->select('*');
        $this->db->from('user'); 
        $this->db->like('role_view','%$id%');
        return $this->db->get();
    }
    // select role_view from user where $username=session and role_view LIKE %$id% 
}
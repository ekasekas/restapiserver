<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function admin_utama(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        $this->load->view('main/index');
    }

    public function admin_ebt(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        $this->load->view('main/index');
    }

    public function view_user(){
        //misal $id = jakarta
        //gawe query ndek model nggo ngelompokno berdasarkan kota2
        //nyeluk query ne
        //gawe session sesuai role, misal dek e login sebagai admin jakarta, dek e kabeh2 link e bersegmen jakarta
        //berarti iki aku salah, haruse di dekek ndek controller pages gak sih nk pingin ndewe2 o ..?
        //trus di kek i if else kyok num row sing tak gawe iki, nk role e gak ditemukan atau kosong atau <1 wi dibaliko halaman utama
        // nk ketemu lagek nge load halaman selanjute
        //gawe tampilan ndek dashboard utama -> berupa list2 nama2 kota sing dijupuk 
        //nk nama kota ne di klik otomatis nampilo (sementara view ne sek, kan role)
        //aku gawe iki gak enek efek apapun :)
        //aku nyoba segmen meng kok gawe foreach? ngko tak pelajari neh
        //aku dikon budhal ning sawah :)
        //oiyo aku wis gawe query model, mbuh wi yo tak celuk gak  enek efek perubahan
        $role_view = $this->input->post('role_view');

        $id= $this->session->userdata('id');
        $this->load->model('model_user', 'role_view');
        $data['RoleView']  = $this->role_view->getRole($id);

        $data = [
            'role_view' => $role_view
        ];

        $result = $this->db->get_where('user', $data);

        if($result->num_rows() < 1){
            $this->load->view('view_user/index');
        }else{
            $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
            // $this->load->view('main/index');
            echo 'hai gaes';
        }
    }

    public function admin_it(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        $this->load->view('admin_it/index');
    }
}

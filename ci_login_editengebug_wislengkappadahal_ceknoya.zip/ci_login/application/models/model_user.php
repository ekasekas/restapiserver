<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class model_user extends CI_Model {

    public function getRole($id){
        $id = $this->session->userdata('id');
        $this->db->select('*');
        $this->db->from('user'); 
        $role_view = $this->db->like('role_view','%$id%');
        $pisah = explode('#',$role_view);
        $jumlah = count($pisah);
        for ($i=0; $i <$jumlah ; $i++) { 
            echo $pisah[$i].'<br>';
        }
        return $this->db->get();
    }
    // select role_view from user where $username=session and role_view LIKE %$id% 

    public function getMaster(){
        $this->db->select('*');
        $this->db->from('master_ebt');
        $this->db->join('site', 'master_ebt.site_id=site.id');
        return $this->db->get();
    }

    // hapus site
    public function deleteSite($id){
        $this->db->delete('site', ['id' => $id]);
    }
    // hapus equipment
    public function deleteEquipment($id){
        $this->db->delete('equipment', ['id' => $id]);
    }
    // hapus syslog
    public function deleteSyslog($id){
        $this->db->delete('system_logbook', ['id' => $id]);
    }

    // public function getSite(){
    //     $this->db->select('*');
    //     $this->db->from('site');
    //     return $this->db->get();
    // }

    // public function getEquipment(){
    //     $this->db->select('*');
    //     $this->db->from('equipment');
    //     $this->db->join('site', 'equipment.site_id=site.id');
    //     return $this->db->get();
    // }

    // public function getSyslog(){
    //     $this->db->select('*');
    //     $this->db->from('system_logbook');
    //     return $this->db->get();
    // }
}
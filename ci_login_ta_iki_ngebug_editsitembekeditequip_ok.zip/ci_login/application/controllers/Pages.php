<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {


    public function dashboard_ebt(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        $role_edit = $data['user']['role_edit'];
        $data['role_edit'] = $data['user']['role_edit'];
        $data['hasil'] = $pisah = explode("#ebt_",$role_edit);
        // $pisah = explode("#ebt_",$role_edit);
        for ($i=0; $i < count($pisah) ; $i++) { 
            $data['']=$pisah[$i];
            // echo $a;
        }
        // $data['a']=$a;
        $this->load->view('main/ebt',$data);
    }

    public function dashboard_ebt2(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        echo 'Dashboard ebt ' . $data['user']['username'].'<br>';
        echo 'Dashboard ebt ' . $data['user']['role_edit'];
        $this->load->view('view_user/ebt');
    }

    public function dashboard_ebt3(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        echo 'Dashboard ebt ' . $data['user']['username'].'<br>';
        echo 'Dashboard ebt ' . $data['user']['role_edit'];
        $this->load->view('admin_it/ebt');
    }

    public function plant_overview(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        echo 'Dashboard ebt ' . $data['user']['username'].'<br>';
        echo 'Dashboard ebt ' . $data['user']['role_edit'];
        $this->load->view('main/overview');
    }

    public function energy_power(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        echo 'Dashboard ebt ' . $data['user']['username'].'<br>';
        echo 'Dashboard ebt ' . $data['user']['role_edit'];
        $this->load->view('main/energy_power');
    }

    public function analysis(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        echo 'Dashboard ebt ' . $data['user']['username'].'<br>';
        echo 'Dashboard ebt ' . $data['user']['role_edit'];
        $this->load->view('main/analysis');
    }

    public function realtime_monitoring(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        echo 'Dashboard ebt ' . $data['user']['username'].'<br>';
        echo 'Dashboard ebt ' . $data['user']['role_edit'];
        $this->load->view('main/realtime_monitoring');
    }

    public function annual_monitoring(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        echo 'Dashboard ebt ' . $data['user']['username'].'<br>';
        echo 'Dashboard ebt ' . $data['user']['role_edit'];
        $this->load->view('main/annual_monitoring');
    }
    
    public function log_monitoring(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        echo 'Dashboard ebt ' . $data['user']['username'].'<br>';
        echo 'Dashboard ebt ' . $data['user']['role_edit'];
        $this->load->view('main/log_monitoring');
    }

    public function page_visualization(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        echo 'Dashboard ebt ' . $data['user']['username'].'<br>';
        echo 'Dashboard ebt ' . $data['user']['role_edit'];
        $this->load->view('main/page_visualization');
    }

    public function configuration(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        echo 'Dashboard ebt ' . $data['user']['username'].'<br>';
        echo 'Dashboard ebt ' . $data['user']['role_edit'];
        $this->load->view('main/configuration');
    }
}